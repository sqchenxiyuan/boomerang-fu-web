# Boomerang Garden SDK

Local ESM package, version 0.7.0. This package contains independently implemented game logic, procedural rendering and reconstructed numeric map layouts; it does not need an installed copy of Boomerang Fu.

[完整 API、控制器所有权与人工接管说明](docs/sdk-api.md)

## Core (Node.js or browser)

```js
import { createSession } from '@boomerang-garden/sdk';
const session = createSession({ mapId: 'canal', seed: 41 });
session.useBot(0);
session.useBot(1);
session.step(60);
console.log(session.snapshot());
session.destroy();
```

The core entry imports no DOM, renderer or Three.js runtime. Simulation advances only when the host calls step(). Button samples use move, attack, dash and throw; the session derives edges. acquire() returns a controller handle with expiring samples. useScript() provides a JavaScript controller. takeover() transfers one actor to human input. Use detached snapshots to inspect state.

## Canvas adapter

```js
import { createBrowserGame } from '@boomerang-garden/sdk/browser';
const game = createBrowserGame(document.querySelector('#arena'), {
  match: { mapId: 'portals', seed: 295 },
  keyboard: true,
});
// Host container must have a visible width and height.
// game.session exposes the same controls as the core entry.
// Call game.destroy() when removing the widget.
```

Use a bundler or an import map for the external three dependency. A raw import map must map both three and the three/addons/ prefix; see docs/sdk-api.md. No application CSS, menus, original meshes, textures, audio, binaries or debug window hooks are included. TypeScript declarations are exported by the core, browser and types subpaths.

## Complete Node match

After installation, run `node node_modules/@boomerang-garden/sdk/examples/node-bots.mjs`. It drives both actors with SDK bot controllers until a normal five-point match finishes, then writes a JSON summary.

This is a local package build, not an npm publication.
