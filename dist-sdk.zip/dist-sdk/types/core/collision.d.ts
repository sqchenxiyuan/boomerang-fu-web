import type { Vec2 } from './math.js';
import type { Arena, Obstacle } from './types.js';
export interface Hit {
    t: number;
    normal: Vec2;
    obstacle?: Obstacle;
}
/** Earliest intersection of a segment with a circle; t is in [0, 1]. */
export declare function segmentCircle(start: Vec2, delta: Vec2, center: Vec2, radius: number): Hit | null;
export declare function pointInBox(point: Vec2, center: Vec2, half: Vec2, padding?: number): boolean;
/** Swept circle against a rounded rectangle (faces plus corner circles). */
export declare function sweepBox(start: Vec2, delta: Vec2, radius: number, center: Vec2, half: Vec2): Hit | null;
export declare function traceObstacles(arena: Arena, start: Vec2, delta: Vec2, radius?: number): Hit | null;
export declare function lineOfSight(arena: Arena, from: Vec2, to: Vec2): boolean;
export declare function moveAndSlide(arena: Arena, start: Vec2, delta: Vec2, radius: number): Vec2;
export declare function onGround(arena: Arena, position: Vec2, margin?: number): boolean;
export declare function safePosition(arena: Arena, position: Vec2, radius: number): boolean;
