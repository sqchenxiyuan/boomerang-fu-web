export declare const RULES: {
    readonly dt: number;
    readonly playerRadius: 0.47;
    readonly worldScale: 0.4;
    readonly walkForce: number;
    readonly unarmedWalkForce: number;
    readonly damping: 11;
    readonly turningSpeed: 12;
    readonly speedLimit: number;
    readonly dashDuration: 0.2;
    readonly dashCooldown: 0.55;
    readonly dashForce: number;
    readonly dashImpulse: number;
    readonly dashBuffer: 0.25;
    readonly attackBuffer: 0.35;
    readonly attackDuration: 0.2;
    readonly attackCooldown: 0.66;
    readonly lungeDuration: 0.1125;
    readonly lungeRecovery: 0.5;
    readonly lungeForce: number;
    readonly lungeImpulse: number;
    readonly attackRange: 1.55;
    readonly attackArc: number;
    readonly aimStart: 0.1;
    readonly aimMoveRecovery: 0.5;
    readonly chargeTime: 1;
    readonly chargeCurveDuration: 0.9;
    readonly discRadius: 0.22;
    readonly discSpeed: 18;
    readonly discOutbound: 0.45;
    readonly discReturnSpeed: 15;
    readonly explosionRadius: 2.5;
    readonly explosionFuse: 1.5;
    readonly countdown: 2.8;
    readonly roundEndDelay: 2.6;
    readonly suddenDeathStart: 35;
    readonly roundLimit: 65;
    readonly scoreGoal: 5;
    readonly powerupInterval: 7;
    readonly powerupLimit: 3;
};
export declare const ROSTER: readonly [{
    readonly name: "瓜瓜";
    readonly subtitle: "WATERMELON";
    readonly color: "#ed7d70";
    readonly accent: "#3a936a";
    readonly kind: "melon";
}, {
    readonly name: "茄子";
    readonly subtitle: "EGGPLANT";
    readonly color: "#ab8de0";
    readonly accent: "#7660b0";
    readonly kind: "eggplant";
}, {
    readonly name: "小橙";
    readonly subtitle: "ORANGE";
    readonly color: "#f2b34e";
    readonly accent: "#e69632";
    readonly kind: "orange";
}, {
    readonly name: "牛奶";
    readonly subtitle: "MILK";
    readonly color: "#82bada";
    readonly accent: "#4a92b4";
    readonly kind: "milk";
}];
export declare const POWERUPS: {
    readonly shield: {
        readonly name: "护盾";
        readonly short: "盾";
        readonly color: "#7ddedb";
        readonly description: "挡住一次伤害";
    };
    readonly haste: {
        readonly name: "加速";
        readonly short: "速";
        readonly color: "#c6e573";
        readonly description: "移动更快，冲刺恢复更快";
    };
    readonly explosive: {
        readonly name: "爆炸镖";
        readonly short: "爆";
        readonly color: "#ffac67";
        readonly description: "飞镖落点产生范围爆炸";
    };
};
