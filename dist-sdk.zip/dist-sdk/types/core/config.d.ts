export declare const RULES: {
    readonly dt: number;
    readonly playerRadius: 0.47;
    readonly worldScale: 0.4;
    readonly walkForce: number;
    readonly unarmedWalkForce: number;
    readonly damping: 11;
    readonly turningSpeed: 12;
    readonly speedLimit: number;
    readonly dashDuration: 0.2;
    readonly dashCooldown: 0.55;
    readonly dashForce: number;
    readonly dashImpulse: number;
    readonly dashBuffer: 0.25;
    readonly attackBuffer: 0.35;
    readonly attackDuration: 0.2;
    readonly attackCooldown: 0.66;
    readonly lungeDuration: 0.1125;
    readonly lungeRecovery: 0.5;
    readonly lungeForce: number;
    readonly lungeImpulse: number;
    readonly attackRange: 1.55;
    readonly attackArc: number;
    readonly aimStart: 0.1;
    readonly aimMoveRecovery: 0.5;
    readonly chargeTime: 1;
    readonly chargeCurveDuration: 0.9;
    readonly discRadius: 0.22;
    readonly discSpeed: 18;
    readonly discOutbound: 0.45;
    readonly discReturnSpeed: 15;
    readonly explosionRadius: number;
    readonly explosionFuse: 1.33;
    readonly countdown: 2.8;
    readonly roundEndDelay: 2.6;
    readonly suddenDeathStart: 180;
    readonly boundaryFinalWidth: number;
    readonly boundaryShrinkSpeed: number;
    readonly outOfBoundsDuration: 3;
    readonly shrinkingOutOfBoundsDuration: 3.75;
    readonly roundResolveDelay: number;
    readonly scoreGoal: 5;
    readonly powerupInterval: 7;
    readonly powerupLimit: 3;
    readonly maxHazardZones: 4096;
};
export declare const ROSTER: readonly [{
    readonly name: "瓜瓜";
    readonly subtitle: "WATERMELON";
    readonly color: "#ed7d70";
    readonly accent: "#3a936a";
    readonly kind: "melon";
}, {
    readonly name: "茄子";
    readonly subtitle: "EGGPLANT";
    readonly color: "#ab8de0";
    readonly accent: "#7660b0";
    readonly kind: "eggplant";
}, {
    readonly name: "小橙";
    readonly subtitle: "ORANGE";
    readonly color: "#f2b34e";
    readonly accent: "#e69632";
    readonly kind: "orange";
}, {
    readonly name: "牛奶";
    readonly subtitle: "MILK";
    readonly color: "#82bada";
    readonly accent: "#4a92b4";
    readonly kind: "milk";
}];
export declare const POWERUPS: {
    readonly shield: {
        readonly name: "护盾";
        readonly short: "盾";
        readonly color: "#7ddedb";
        readonly description: "挡住一次伤害";
    };
    readonly haste: {
        readonly name: "加速";
        readonly short: "速";
        readonly color: "#c6e573";
        readonly description: "移动更快，冲刺恢复更快";
    };
    readonly explosive: {
        readonly name: "爆炸镖";
        readonly short: "爆";
        readonly color: "#ffac67";
        readonly description: "飞镖落点产生范围爆炸";
    };
    readonly wallDash: {
        readonly name: "穿墙冲刺";
        readonly short: "穿";
        readonly color: "#c5a6ef";
        readonly description: "冲刺穿过障碍，落点需有安全空间";
    };
    readonly reverse: {
        readonly name: "头昏眼花";
        readonly short: "乱";
        readonly color: "#eb83be";
        readonly description: "移动方向反转 6 秒，不占强化槽";
    };
    readonly multi: {
        readonly name: "分裂镖";
        readonly short: "裂";
        readonly color: "#e8dd83";
        readonly description: "飞行中分裂成小镖，集齐后恢复一把武器";
    };
    readonly teleport: {
        readonly name: "传送镖";
        readonly short: "传";
        readonly color: "#8fafff";
        readonly description: "有飞镖在场时按冲刺，传送到自己的安全飞镖落点";
    };
    readonly fire: {
        readonly name: "火焰镖";
        readonly short: "火";
        readonly color: "#ff7d57";
        readonly description: "留下火焰；点燃对手，也要留意自己的火";
    };
    readonly extra: {
        readonly name: "双回旋镖";
        readonly short: "双";
        readonly color: "#ffd173";
        readonly description: "多一把武器，可连续投出两镖";
    };
    readonly ice: {
        readonly name: "冰冻镖";
        readonly short: "冰";
        readonly color: "#91e4fa";
        readonly description: "留下冰面减速，冰爆可冻结对手；与火互斥";
    };
    readonly disguise: {
        readonly name: "伪装";
        readonly short: "隐";
        readonly color: "#adc991";
        readonly description: "静止片刻自动伪装；移动或攻击解除";
    };
    readonly controlled: {
        readonly name: "遥控镖";
        readonly short: "控";
        readonly color: "#c3a8ff";
        readonly description: "投出后按住投掷，用方向键控制飞镖";
    };
    readonly shrink: {
        readonly name: "缩小战场";
        readonly short: "圈";
        readonly color: "#ef9fb0";
        readonly description: "立即向拾取位置缩圈，不占强化槽";
    };
    readonly decoy: {
        readonly name: "诱饵";
        readonly short: "饵";
        readonly color: "#9bdcc3";
        readonly description: "每回合首次冲刺或传送释放替身，吸引对手攻击";
    };
};
