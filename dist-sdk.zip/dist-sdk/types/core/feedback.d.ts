import type { Actor, GameState } from './types.js';
/** Shared copy for the full application and the embeddable SDK HUD. */
export declare function eliminationLabel(actor: Actor): string;
export declare function boundaryNotice(state: GameState): string;
/** The original warning appears after 20% of the grace period and accelerates. */
export declare function boundaryWarning(actor: Actor): {
    visible: boolean;
    seconds: number;
    intensity: number;
    pulse: number;
};
