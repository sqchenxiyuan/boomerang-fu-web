export interface Vec2 {
    x: number;
    y: number;
}
export declare const v: (x?: number, y?: number) => Vec2;
export declare const add: (a: Vec2, b: Vec2) => Vec2;
export declare const sub: (a: Vec2, b: Vec2) => Vec2;
export declare const mul: (a: Vec2, n: number) => Vec2;
export declare const dot: (a: Vec2, b: Vec2) => number;
export declare const length: (a: Vec2) => number;
export declare const distance: (a: Vec2, b: Vec2) => number;
export declare const normalize: (a: Vec2) => Vec2;
export declare const clamp: (x: number, a: number, b: number) => number;
export declare const lerp: (a: number, b: number, t: number) => number;
export declare const lerpV: (a: Vec2, b: Vec2, t: number) => Vec2;
export declare const rotate: (p: Vec2, angle: number) => Vec2;
export declare const cross: (a: Vec2, b: Vec2) => number;
export declare const reflect: (dir: Vec2, normal: Vec2) => Vec2;
export declare const clampLength: (a: Vec2, max: number) => Vec2;
export declare const angleBetween: (a: Vec2, b: Vec2) => number;
export declare class Random {
    seed: number;
    constructor(seed: number);
    next(): number;
    range(min: number, max: number): number;
    pick<T>(items: readonly T[]): T;
}
