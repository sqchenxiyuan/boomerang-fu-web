import type { Phase } from './types.js';
/** Static-source timings and explicitly adapted Web timings; see transitions-analysis.md. */
export declare const PRESENTATION: {
    readonly reveal: 1;
    readonly firstSpawn: 0.1;
    readonly spawnInterval: 0.4;
    readonly crowdedSpawnInterval: 0.35;
    readonly landing: 0.4333;
    readonly landingSettle: 0.18;
    readonly ready: 1;
    readonly go: 0.7;
    readonly equipDelay: 1.2;
    readonly roundHold: 1.45;
    readonly close: 0.5;
    readonly scoreReveal: 0.4;
    readonly scoreHold: 0.75;
};
/** Shield impact has no unconditional freeze in the inspected original code. */
export declare const HIT_STOP: {
    readonly death: 0.1;
    readonly deflect: 0.25;
    readonly shield: 0;
    readonly meleeClash: 0.2;
};
export declare const ROUND_END_DURATION: number;
export interface IntroPose {
    visible: boolean;
    /** Vertical offset in the Web world's units; this amplitude is an art choice. */
    height: number;
    scale: number;
    /** Multiply vertical scale by this, and horizontal scale by 1 / sqrt(squash). */
    squash: number;
    /** Landing ring strength, zero outside the short settling window. */
    landing: number;
}
export interface PresentationState {
    phase: Phase;
    phaseTime: number;
    round: number;
    winnerId: number | null;
    actors: readonly {
        id: number;
        score: number;
    }[];
}
export interface TransitionPresentation {
    stage: 'none' | 'reveal' | 'spawn' | 'ready' | 'go' | 'result' | 'close' | 'score';
    label: string;
    subtitle: string;
    /** 0 covers everything, 1 reveals everything. Use a circle reaching all corners. */
    wipeRadius: number;
    /** Multiplier for camera distance/FOV; smaller values gently move closer. */
    cameraScale: number;
    /** Scalar text entrance animation, independent of the authoritative unlock. */
    labelScale: number;
    scoreOpacity: number;
    showScores: boolean;
    winnerId: number | null;
}
/** The simulation must use this same duration to switch countdown -> playing. */
export declare function introDuration(actorCount: number): number;
/** actorIndex is the presentation order, independent of actor ID or spawn position. */
export declare function introPose(time: number, actorIndex: number, actorCount: number): IntroPose;
/** Pure snapshot sampling: no timers, mutation, randomness or control side effects. */
export declare function transitionPresentation(state: PresentationState): TransitionPresentation;
