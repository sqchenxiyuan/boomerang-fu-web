import type { GameEvent } from '../core/types.js';
/** Small synthesized SFX bank; no network requests or original audio assets. */
export declare class AudioEngine {
    private context;
    private master;
    muted: boolean;
    private recent;
    unlock(): void;
    toggle(): boolean;
    destroy(): void;
    private tone;
    play(events: GameEvent[]): void;
}
