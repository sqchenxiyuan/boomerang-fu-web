import type { Command } from '../core/types.js';
export declare class Input {
    private readonly target?;
    private held;
    private pressed;
    private released;
    private padPrevious;
    private padSystemPrevious;
    private padBlocked;
    private blocked;
    private enabled;
    onPause: () => void;
    onSound: () => void;
    constructor(target?: HTMLElement | undefined);
    private keyDown;
    private keyUp;
    clear: () => void;
    setEnabled(enabled: boolean): void;
    pollSystemButtons(): void;
    read(playerCount: number): Map<number, Command>;
    dispose(): void;
}
