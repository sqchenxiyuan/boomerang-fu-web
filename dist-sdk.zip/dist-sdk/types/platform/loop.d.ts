/** Fixed simulation clock. Long background gaps are discarded, never fast-forwarded. */
export declare class FixedLoop {
    private accumulator;
    private previous;
    private handle;
    private elapsed;
    private running;
    paused: boolean;
    onStep: () => void;
    onFrame: (_alpha: number, _elapsed: number, _dt: number) => void;
    start(): void;
    reset(): void;
    private frame;
    stop(): void;
}
