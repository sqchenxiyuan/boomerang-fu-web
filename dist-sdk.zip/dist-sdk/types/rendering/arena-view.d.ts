import * as THREE from 'three';
import type { Arena } from '../core/types.js';
export interface ArenaView {
    root: THREE.Group;
    obstacles: Map<string, THREE.Group>;
    water: THREE.Mesh;
    flags: THREE.Object3D[];
    portals: Map<string, THREE.Group>;
}
export declare function createArenaView(arena: Arena): ArenaView;
