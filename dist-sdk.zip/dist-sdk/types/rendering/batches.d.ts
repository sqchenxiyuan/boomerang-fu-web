import * as THREE from 'three';
/** A renderer owns its buffers and material. Resetting the count never allocates
 * or releases GPU objects; final disposal is deliberately a separate operation. */
export declare class InstanceBatch {
    readonly capacity: number;
    readonly mesh: THREE.InstancedMesh<THREE.BufferGeometry, THREE.ShaderMaterial>;
    private alpha;
    private matrix;
    private position;
    private scale;
    private rotation;
    private quaternion;
    private colors;
    private used;
    private disposed;
    dropped: number;
    constructor(geometry: THREE.BufferGeometry, capacity: number);
    begin(): void;
    add(x: number, y: number, z: number, sx: number, sy: number, sz: number, color: string | number, opacity?: number, rx?: number, ry?: number, rz?: number): boolean;
    end(): void;
    clear(): void;
    get count(): number;
    dispose(): void;
}
/** Merge only explicitly static subtrees. Each excluded object remains reachable
 * under the same parent, so flag/portal animation and broken obstacles still work. */
export declare function mergeStaticMeshes(root: THREE.Object3D, excluded?: Set<THREE.Object3D<THREE.Object3DEventMap>>): number;
