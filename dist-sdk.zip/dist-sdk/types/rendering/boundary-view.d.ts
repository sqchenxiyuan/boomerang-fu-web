import * as THREE from 'three';
import type { GameState } from '../core/types.js';
/** Original boundary semantics, rebuilt with procedural Web geometry and shaders. */
export declare class BoundaryView {
    readonly root: THREE.Group<THREE.Object3DEventMap>;
    private line;
    private glow;
    private marker;
    private walls;
    private arrows;
    private warnings;
    constructor();
    update(state: GameState, menu: boolean): void;
    private disposeWarning;
    reset(): void;
    dispose(): void;
}
