import * as THREE from 'three';
import type { Actor } from '../core/types.js';
import { type DeathModel } from './death-models.js';
export interface CharacterView {
    root: THREE.Group;
    body: THREE.Group;
    leftArm: THREE.Group;
    rightArm: THREE.Group;
    feet: THREE.Group[];
    weapon: THREE.Group;
    shield: THREE.Mesh;
    slash: THREE.Mesh;
    aim: THREE.Group;
    ring: THREE.Mesh;
    label: THREE.Sprite;
    shadow: THREE.Mesh;
    death: DeathModel;
    lastAttack: number;
}
export declare function createCharacter(actor: Actor): CharacterView;
export declare function updateCharacter(view: CharacterView, actor: Actor, alpha: number, time: number): void;
