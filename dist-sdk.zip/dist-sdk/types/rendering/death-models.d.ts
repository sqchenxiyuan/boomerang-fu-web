import * as THREE from 'three';
import type { Actor } from '../core/types.js';
export interface DeathModel {
    root: THREE.Group;
    stump: THREE.Group;
    piece: THREE.Group;
    squash: THREE.Group;
}
/** These meshes are our own fixed cut shapes, following the original prefab swap
 * semantics. No original game meshes/textures and no runtime arbitrary mesh cut. */
export declare function createDeathModel(actor: Actor): DeathModel;
