import type { Actor, DeathState } from '../core/types.js';
/** Stateless Web presentation. Serialized original values and adaptations are in
 * docs/death-feedback-analysis.md. Nothing here decides whether an actor dies. */
export declare const DEATH_VISUALS: {
    readonly faceplantTime: 0.75;
    readonly sliceSpeed: 8;
    readonly sliceUpward: 4;
    readonly sliceGravity: number;
    readonly sliceBounce: 0.7;
    readonly sliceDrag: 2.5;
    readonly splatIn: 1;
    readonly splatLifetime: 4;
    readonly splatOut: 0.5;
};
export interface DeathPose {
    baseVisible: boolean;
    pieceVisible: boolean;
    baseHeight: number;
    baseTilt: number;
    baseScale: {
        x: number;
        y: number;
        z: number;
    };
    piece: {
        x: number;
        y: number;
        z: number;
        spin: number;
    };
}
export declare function sampleDeathPose(death: DeathState, time: number): DeathPose;
export declare function sampleFallPose(fall: NonNullable<Actor['fall']>): {
    height: number;
    tilt: number;
    scale: number;
};
export interface DeathParticleSample {
    kind: 'juice' | 'water' | 'bubble' | 'cloud' | 'burst' | 'dust';
    x: number;
    y: number;
    z: number;
    radius: number;
    opacity: number;
}
export declare function sampleDeathParticles(death: DeathState, time: number): DeathParticleSample[];
export interface DeathRingSample {
    radius: number;
    opacity: number;
}
export declare function sampleDeathRings(death: DeathState, time: number): DeathRingSample[];
export interface DeathSplatSample {
    x: number;
    z: number;
    radius: number;
    angle: number;
    opacity: number;
}
export declare function sampleDeathSplats(death: DeathState, time: number): DeathSplatSample[];
