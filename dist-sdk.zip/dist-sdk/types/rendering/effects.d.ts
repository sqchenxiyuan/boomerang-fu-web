import * as THREE from 'three';
import type { GameEvent, GameState } from '../core/types.js';
/** Three fixed GPU batches cover transient and snapshot-driven death effects. */
export declare class Effects {
    readonly root: THREE.Group<THREE.Object3DEventMap>;
    private particles;
    private waves;
    private random;
    private clock;
    private state?;
    private transientShake;
    private particlesBatch;
    private ringsBatch;
    private splatsBatch;
    private disposed;
    shake: number;
    constructor();
    emit(event: GameEvent): void;
    syncDeaths(state: GameState): void;
    update(dt: number, state?: GameState): void;
    private rebuild;
    stats(): {
        particles: number;
        rings: number;
        splats: number;
        dropped: number;
        batches: number;
    };
    clear(): void;
    dispose(): void;
}
