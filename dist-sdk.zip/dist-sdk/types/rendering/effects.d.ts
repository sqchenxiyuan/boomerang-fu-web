import * as THREE from 'three';
import type { GameEvent, GameState } from '../core/types.js';
export declare class Effects {
    readonly root: THREE.Group<THREE.Object3DEventMap>;
    private particles;
    private waves;
    private random;
    private deaths;
    private transientShake;
    private deathShake;
    shake: number;
    emit(event: GameEvent): void;
    /** Rebuildable, pause-safe death presentation. Call once for each rendered snapshot. */
    syncDeaths(state: GameState): void;
    update(dt: number): void;
    clear(): void;
}
