import * as THREE from 'three';
import type { GameEvent } from '../core/types.js';
export declare class Effects {
    readonly root: THREE.Group<THREE.Object3DEventMap>;
    private particles;
    private waves;
    private random;
    shake: number;
    emit(event: GameEvent): void;
    update(dt: number): void;
    clear(): void;
}
