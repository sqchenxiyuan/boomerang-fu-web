import * as THREE from 'three';
export declare function material(color: string, roughness?: number): THREE.MeshStandardMaterial;
export declare function mesh(geometry: THREE.BufferGeometry, color: string): THREE.Mesh;
export declare function box(w: number, h: number, d: number, color: string): THREE.Mesh;
export declare function sphere(r: number, color: string, detail?: number): THREE.Mesh;
export declare function cylinder(top: number, bottom: number, height: number, color: string, sides?: number): THREE.Mesh;
export declare function place<T extends THREE.Object3D>(object: T, x: number, y: number, z: number, parent: THREE.Object3D): T;
export declare function makeBoomerang(color?: string): THREE.Group;
export declare function shadow(radius: number, opacity?: number): THREE.Mesh;
