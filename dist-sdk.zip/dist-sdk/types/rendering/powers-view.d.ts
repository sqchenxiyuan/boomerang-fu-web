import * as THREE from 'three';
import type { GameState } from '../core/types.js';
/** Ground hazards and status markers use the same simulation clock as combat. */
export declare class PowersView {
    readonly root: THREE.Group<THREE.Object3DEventMap>;
    private patches;
    private edges;
    private sparks;
    private crystals;
    private disposed;
    constructor();
    update(state: GameState): void;
    clear(): void;
    dispose(): void;
}
