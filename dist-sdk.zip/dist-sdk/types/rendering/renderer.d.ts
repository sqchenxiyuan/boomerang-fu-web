import * as THREE from 'three';
import type { GameEvent, GameState } from '../core/types.js';
export declare class GameRenderer {
    readonly canvas: HTMLCanvasElement;
    readonly renderer: THREE.WebGLRenderer;
    private scene;
    private camera;
    private arena;
    private characters;
    private discs;
    private pickups;
    private effects;
    private boundary;
    private resizeObserver;
    private width;
    private height;
    private cameraTarget;
    private arenaSource;
    private previousTime;
    constructor(container: HTMLElement, state: GameState);
    reset(state: GameState): void;
    private resize;
    events(events: GameEvent[]): void;
    draw(state: GameState, alpha: number, elapsed: number, dt: number, menu: boolean): void;
    stats(): {
        calls: number;
        triangles: number;
        geometries: number;
        textures: number;
    };
    dispose(): void;
}
