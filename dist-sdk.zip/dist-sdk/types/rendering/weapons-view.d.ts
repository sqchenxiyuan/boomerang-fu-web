import * as THREE from 'three';
import type { Disc, GameEvent, GameState } from '../core/types.js';
export declare function discEffectColor(disc: Disc): string;
/** Persistent trail history belongs to this renderer, never to authoritative
 * simulation. Simulation timestamps make repeated pause frames identical. */
export declare class WeaponsView {
    readonly root: THREE.Group<THREE.Object3DEventMap>;
    private trails;
    private ribbon;
    private rings;
    private arcs;
    private lastTime;
    private round;
    private disposed;
    constructor();
    observe(event: GameEvent): void;
    update(state: GameState, alpha: number): void;
    stats(): {
        trailCount: number;
        segments: number;
        rings: number;
        arcs: number;
    };
    clear(): void;
    dispose(): void;
}
