import { GameSession } from './session.js';
import type { GameEvent, GameState, MatchOptions } from '../core/types.js';
import type { SessionSnapshot } from './types.js';
export interface BrowserFrame {
    state: GameState;
    status: SessionSnapshot['status'];
    alpha: number;
    elapsed: number;
    dt: number;
    events: GameEvent[];
    muted: boolean;
}
export interface BrowserGameOptions {
    match?: Partial<MatchOptions>;
    autoStart?: boolean;
    keyboard?: boolean;
    inputTarget?: HTMLElement;
    hud?: boolean;
    pauseOnBlur?: boolean;
    onFrame?: (frame: BrowserFrame) => void;
}
/** Browser-only adapter. The session owns state; this adapter owns exactly one RAF and input device. */
export declare class BrowserGame {
    private readonly container;
    private readonly options;
    readonly session: GameSession;
    readonly canvas: HTMLCanvasElement;
    private readonly renderer;
    private readonly input;
    private readonly audio;
    private readonly loop;
    private readonly unsubscribe;
    private readonly originalPosition;
    private readonly overlay;
    private readonly wipe;
    private readonly center;
    private readonly score;
    private readonly notice;
    private events;
    private disposed;
    private preview;
    private frames;
    private elapsed;
    private frameErrors;
    onFrame: (frame: BrowserFrame) => void;
    constructor(container: HTMLElement, options?: BrowserGameOptions);
    private assertLive;
    private focus;
    private blur;
    private visibility;
    start(options?: Partial<MatchOptions>): void;
    pause(): void;
    resume(): void;
    /** A paused world rendered as a menu diorama; no hidden match runs in the background. */
    showPreview(options?: Partial<MatchOptions>): void;
    toggleSound(): boolean;
    stats(): {
        frames: number;
        elapsed: number;
        frameErrors: number;
        render: {
            calls: number;
            triangles: number;
            geometries: number;
            textures: number;
        };
    };
    destroy(): void;
}
export declare function createBrowserGame(container: HTMLElement, options?: BrowserGameOptions): BrowserGame;
export type { Action, ScriptController, SessionSnapshot, SessionEvent, ControlHandle, ExternalController, } from './types.js';
