import type { Vec2 } from '../core/math.js';
import type { Actor, Command, GameEvent, GameState, MatchOptions } from '../core/types.js';
import type { Action } from './types.js';
export interface ActionSample {
    move: Vec2;
    attack: boolean;
    dash: boolean;
    throw: boolean;
}
export declare const neutralSample: () => ActionSample;
export declare function integer(value: number, min: number, max: number, name: string): number;
export declare function actionSample(action: Action): ActionSample;
export declare function humanCommand(command: Command): Command;
export declare function commandFromSamples(sample: ActionSample, previous: ActionSample): Command;
export declare function matchOptions(base: MatchOptions, overrides?: Partial<MatchOptions>): MatchOptions;
/** Controller-only RNG streams never consume the simulation's pickup RNG. */
export declare class BotDriver {
    #private;
    private readonly seed;
    constructor(seed: number);
    command(state: GameState, actor: Actor): Command;
    resetActor(actorId: number): void;
    reset(): void;
    observe(events: readonly GameEvent[]): void;
}
