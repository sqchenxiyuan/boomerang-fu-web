export { GameSession, createSession } from './session.js';
export type * from './types.js';
export type * from '../core/types.js';
export type { Vec2 } from '../core/math.js';
export { MAPS, ORIGINAL_MAPS, CUSTOM_MAPS } from '../core/arena.js';
export type { MapInfo } from '../core/original-maps.js';
