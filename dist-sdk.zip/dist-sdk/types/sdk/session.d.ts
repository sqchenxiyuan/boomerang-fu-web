import type { Command, GameState, MatchOptions } from '../core/types.js';
import type { ControlHandle, ExternalController, ScriptController, SessionAPI, SessionEvent, SessionSnapshot } from './types.js';
/** Owns the simulation, input arbitration and event fan-out; no browser dependencies. */
export declare class GameSession implements SessionAPI {
    #private;
    constructor(options?: Partial<MatchOptions>);
    start(options?: Partial<MatchOptions>): void;
    pause(): void;
    resume(): void;
    step(ticks?: number): void;
    getState(): GameState;
    snapshot(): SessionSnapshot;
    onEvent(listener: (event: SessionEvent) => void): () => void;
    acquire(actorId: number, label?: string): ExternalController;
    useScript(actorId: number, controller: ScriptController, label?: string): ControlHandle;
    useBot(actorId: number): void;
    useHuman(actorId: number, humanIndex?: number): void;
    takeover(actorId: number, humanIndex?: number): ControlHandle;
    submitHuman(humanIndex: number, command: Command): void;
    destroy(): void;
}
export declare function createSession(options?: Partial<MatchOptions>): GameSession;
