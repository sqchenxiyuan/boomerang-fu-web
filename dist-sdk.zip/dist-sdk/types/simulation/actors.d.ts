import type { Actor, Command, GameState } from '../core/types.js';
/** Dash checks teleport before the ordinary dash cooldown, as Player.Dash does. */
export declare function tryTeleport(state: GameState, actor: Actor): boolean;
export declare function tickActor(state: GameState, actor: Actor, command: Command, dt: number): void;
