import type { Actor, Command, GameState } from '../core/types.js';
export declare function tickActor(state: GameState, actor: Actor, command: Command, dt: number): void;
