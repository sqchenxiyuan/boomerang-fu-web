import type { Random } from '../core/math.js';
import type { Actor, Command, GameState } from '../core/types.js';
export declare class BotController {
    private brains;
    reset(): void;
    resetActor(id: number): void;
    command(state: GameState, actor: Actor, random: Random, dt: number): Command;
}
