import type { Random, Vec2 } from '../core/math.js';
import type { Actor, Arena, BoundaryState, GameState } from '../core/types.js';
export declare function boundaryCurve(progress: number): number;
export declare function createBoundary(arena: Arena): BoundaryState;
/** Original checks the actor origin, with strict rectangle edges, not body overlap. */
export declare function isInBoundary(boundary: BoundaryState, point: Vec2, inset?: number): boolean;
export declare function clampToBoundary(boundary: BoundaryState, point: Vec2, inset?: number): Vec2;
export declare function startShrinkingBoundary(state: GameState, target: Vec2, ownerId?: number | null): void;
export declare function stopShrinkingBoundary(state: GameState): void;
export declare function tickBoundary(state: GameState, random: Random, dt: number): void;
export declare function tickActorBoundary(state: GameState, actor: Actor, dt: number): void;
