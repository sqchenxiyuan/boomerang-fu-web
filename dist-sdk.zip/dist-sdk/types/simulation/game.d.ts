import type { Command, GameEvent, GameState, MatchOptions } from '../core/types.js';
/** Sole authoritative owner of gameplay state. No rendering or DOM dependencies. */
export declare class Game {
    state: GameState;
    private random;
    constructor(options?: MatchOptions);
    start(options: MatchOptions): void;
    step(commands?: ReadonlyMap<number, Command>): void;
    drainEvents(): GameEvent[];
}
