import type { Vec2 } from '../core/math.js';
import type { Actor, Arena, GameState } from '../core/types.js';
type FallKind = 'water' | 'cliff';
/** Web arenas designate interior pits as water and the outer edge as a cliff. */
export declare function hazardKind(arena: Arena, position: Vec2): FallKind | null;
/** Original Dash rejects strictly after .33 seconds and permits only one midair rescue. */
export declare function canRescueFall(actor: Actor): boolean;
/** The caller still checks ordinary dash availability and supplies its impulse. */
export declare function rescueFall(actor: Actor): boolean;
/**
 * Call after movement, once per effective simulation tick. Entry starts at elapsed=0;
 * subsequent ticks advance the timer. Game owns pause/hit-stop and the movement clock.
 * Existing velocity drives drift; this module never moves or scores an actor itself.
 */
export declare function tickFall(state: GameState, actor: Actor, dt: number): void;
export {};
