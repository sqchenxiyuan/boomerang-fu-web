import type { Actor, Disc, GameState } from '../core/types.js';
export declare const discCapacity: (actor: Actor) => number;
/** `armed` remains compatible with callers constructing older SDK snapshots. */
export declare const heldDiscs: (actor: Actor) => number;
export declare function setHeldDiscs(actor: Actor, count: number): void;
export declare function recoverDisc(state: GameState, disc: Disc, caught?: boolean): void;
