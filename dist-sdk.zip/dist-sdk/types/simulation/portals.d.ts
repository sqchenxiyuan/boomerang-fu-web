import type { Vec2 } from '../core/math.js';
import type { Arena, Disc, GameState, Portal } from '../core/types.js';
export declare const PORTAL_COOLDOWN: number;
export interface PortalHit {
    t: number;
    portal: Portal;
    destination: Vec2;
}
export declare function portalDestination(arena: Arena, portal: Portal, radius: number): Vec2 | null;
/** Entry requires crossing the boundary. Remaining inside a pad never repeatedly teleports. */
export declare function tracePortal(arena: Arena, start: Vec2, delta: Vec2, radius: number, cooldown?: number): PortalHit | null;
export declare function teleportDisc(state: GameState, disc: Disc, hit: PortalHit): void;
/** Call after actor movement and before melee/separation. Returns IDs whose AI path was invalidated. */
export declare function tickActorPortals(state: GameState, dt: number): number[];
