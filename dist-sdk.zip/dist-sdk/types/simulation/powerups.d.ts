import type { Random } from '../core/math.js';
import type { Actor, GameState, PowerupKind } from '../core/types.js';
export declare function grantPowerup(state: GameState, actor: Actor, kind: PowerupKind): void;
export declare function tickPowerups(state: GameState, random: Random, dt: number): void;
