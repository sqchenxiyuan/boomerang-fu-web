import type { Actor, GameState } from '../core/types.js';
export declare function throwDisc(state: GameState, actor: Actor): boolean;
export declare function tickDiscs(state: GameState, dt: number): void;
