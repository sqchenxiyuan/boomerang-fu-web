import type { Actor, GameState, MatchOptions } from '../core/types.js';
export declare const defaultOptions: () => MatchOptions;
export declare function makeActor(id: number, controller: Actor['controller'], humanIndex: number): Actor;
export declare function createState(options?: MatchOptions): GameState;
export declare function resetRound(state: GameState): void;
