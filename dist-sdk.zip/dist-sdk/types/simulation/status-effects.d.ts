import type { Vec2 } from '../core/math.js';
import type { Actor, DecoyState, GameState, HazardZone } from '../core/types.js';
export declare function breakDisguise(actor: Actor): void;
/** Deterministic cells: all clocks and ownership stay in the SDK snapshot. */
export declare function addZone(state: GameState, kind: HazardZone['kind'], position: Vec2, ownerId: number, radius?: number, duration?: number): void;
export declare function igniteActor(state: GameState, actor: Actor, sourceId: number): void;
export declare function freezeActor(state: GameState, actor: Actor, sourceId: number, fromIceFloor?: boolean): void;
export declare function spawnDecoy(state: GameState, actor: Actor): void;
export declare function hitDecoy(state: GameState, decoy: DecoyState, sourceId: number): boolean;
export declare function tickStatusEffects(state: GameState, dt: number): void;
