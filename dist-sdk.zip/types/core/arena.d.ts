import type { Arena, MapId, MapRotation } from './types.js';
import type { MapInfo } from './original-maps.js';
export { ORIGINAL_MAPS } from './original-maps.js';
export declare const CUSTOM_MAPS: readonly [{
    readonly id: "courtyard";
    readonly name: "山间庭院";
    readonly subtitle: "THE LITTLE COURTYARD";
    readonly description: "绕过喷泉，沿墙反弹。";
    readonly theme: "garden";
}, {
    readonly id: "canal";
    readonly name: "双桥水道";
    readonly subtitle: "CANAL CROSSING";
    readonly description: "守住桥头，向水面另一侧投镖。";
    readonly theme: "canal";
}, {
    readonly id: "market";
    readonly name: "货箱集市";
    readonly subtitle: "CRATE MARKET";
    readonly description: "打碎货箱，打开新的射线与近路。";
    readonly theme: "sandstone";
}, {
    readonly id: "switchback";
    readonly name: "折返回廊";
    readonly subtitle: "SWITCHBACK HALL";
    readonly description: "转角伏击，沿长墙反弹。";
    readonly theme: "ruins";
}, {
    readonly id: "portals";
    readonly name: "跃迁花园";
    readonly subtitle: "PORTAL GARDEN";
    readonly description: "人和飞镖都能穿过同色传送门。";
    readonly theme: "garden";
}];
export declare const MAPS: readonly MapInfo[];
export declare function mapInfo(id?: MapId): MapInfo;
/** Selection is independent of combat RNG, making SDK replay and rotation stable. */
export declare function selectRoundMap(first?: MapId, rotation?: MapRotation, round?: number): MapId;
export declare function createArena(id?: MapId): Arena;
