import type { Vec2 } from './math.js';
import type { Arena, Floor, Obstacle } from './types.js';
export declare function pathBounds(paths: Vec2[][]): {
    min: Vec2;
    max: Vec2;
};
export declare function localPoint(point: Vec2, shape: {
    position: Vec2;
    angle?: number;
}): Vec2;
export declare function closestOnSegment(point: Vec2, a: Vec2, b: Vec2): Vec2;
/** Even-odd contours preserve holes and disjoint islands without assuming convexity. */
export declare function inPaths(point: Vec2, paths: Vec2[][]): boolean;
export declare function floorContains(floor: Floor, point: Vec2): boolean;
export declare function shapeContains(shape: {
    position: Vec2;
    angle?: number;
    radius?: number;
    paths: Vec2[][];
}, point: Vec2): boolean;
/** Fixed XY tiles share a spatial index; moving parents are always queried live.
 * Active/warning flags remain on the original objects, so collapsing tiles do
 * not require a rebuild or a second copy of the physical state. */
export declare function supportedAt(arena: Arena, point: Vec2): boolean;
export declare function obstaclePaths(obstacle: Obstacle): Vec2[][];
export declare function obstacleDistance(obstacle: Obstacle, point: Vec2): number;
/** Broad phase avoids scanning far polygon contours for every navigation sample. */
export declare function obstacleOverlaps(obstacle: Obstacle, point: Vec2, radius: number): boolean;
