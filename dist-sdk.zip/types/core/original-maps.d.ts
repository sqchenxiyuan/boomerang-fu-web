import type { Arena, MapId } from './types.js';
export interface MapInfo {
    id: MapId;
    name: string;
    subtitle: string;
    description: string;
    theme: 'garden' | 'canal' | 'sandstone' | 'ruins';
    source: 'original' | 'custom';
    tutorial?: boolean;
    minPlayers?: number;
    maxPlayers?: number;
    complexity?: number | string;
    requiredDLC?: number;
    supportedMatchTypes?: string[];
    buildIndices?: number[];
}
export interface OriginalMapRecord {
    info: MapInfo;
    arena: Arena;
    provenance: {
        sceneFile: string;
        sceneSha256: string;
        levelAssetPathId: number;
    };
}
/** Numeric scene geometry and rules, independently rendered with procedural Web meshes. */
export declare const ORIGINAL_MAP_RECORDS: readonly OriginalMapRecord[];
export declare const ORIGINAL_MAPS: readonly MapInfo[];
export declare function createOriginalArena(id: MapId): Arena;
