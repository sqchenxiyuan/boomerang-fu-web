import type { GameEvent, GameState } from '../core/types.js';
import type { AudioSettings, MusicScene } from './audio-types.js';
export type { AudioSettings } from './audio-types.js';
/** Gesture-unlocked, per-game Tone.js context. Audio never advances or randomizes physics. */
export declare class AudioEngine {
    private context;
    private graph;
    private settings;
    private scene;
    private active;
    private disposed;
    private error;
    get muted(): boolean;
    getSettings(): AudioSettings;
    configure(settings: Partial<AudioSettings>): void;
    unlock(): void;
    update(state: GameState, paused: boolean, preview: boolean): void;
    play(events: readonly GameEvent[]): void;
    reset(): void;
    toggle(): boolean;
    stats(): {
        unlocked: boolean;
        contextState: string;
        scene: MusicScene;
        active: boolean;
        level: number;
        musicNotes: number;
        effectEvents: number;
        error: string | null;
    };
    destroy(): void;
}
