/** Fixed simulation clock. Long background gaps are discarded, never fast-forwarded. */
export declare class FixedLoop {
    private accumulator;
    private previous;
    private handle;
    private elapsed;
    private running;
    private scale;
    private discarded;
    private stepsTaken;
    paused: boolean;
    onStep: () => boolean | void;
    onFrame: (_alpha: number, _elapsed: number, _dt: number) => void;
    get timeScale(): number;
    set timeScale(value: number);
    stats(): {
        steps: number;
        discardedSeconds: number;
        timeScale: number;
    };
    start(): void;
    reset(): void;
    private frame;
    stop(): void;
}
