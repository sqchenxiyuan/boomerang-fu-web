import type { Arena } from '../core/types.js';
import type { Vec2 } from '../core/math.js';
export interface ArenaCameraFrame {
    center: Vec2;
    half: Vec2;
    height: number;
}
/** Camera3D.cameraAngle = (0, -0.4, -0.7), mapped from Unity XY/-Z to Web XZ/Y. */
export declare const ORIGINAL_CAMERA_UP = 0.7;
export declare const ORIGINAL_CAMERA_BACK = 0.4;
/** Fit the supplied topology once, not decorative oceans or legacy fixed props. */
export declare function arenaCameraFrame(arena: Arena): ArenaCameraFrame;
/** Fixed camera pitch; exact perspective corner constraints at ground and head
 * height avoid clipping wide or portrait layouts. Return distance to target. */
export declare function arenaCameraDistance(frame: ArenaCameraFrame, aspect: number, fov?: number): number;
