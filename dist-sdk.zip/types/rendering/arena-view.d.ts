import * as THREE from 'three';
import type { Arena } from '../core/types.js';
import type { OriginalPlantsView } from './original-plants.js';
export interface ArenaView {
    root: THREE.Group;
    obstacles: Map<string, THREE.Group>;
    water: THREE.Mesh;
    flags: THREE.Object3D[];
    portals: Map<string, THREE.Group>;
    floors: Map<string, THREE.Group>;
    mechanisms: Map<string, THREE.Group>;
    plants?: OriginalPlantsView;
}
export declare function createArenaView(arena: Arena): ArenaView;
