import * as THREE from 'three';
import type { Actor } from '../core/types.js';
import { type DeathModel } from './death-models.js';
export interface CharacterView {
    root: THREE.Group;
    body: THREE.Group;
    leftArm: THREE.Group;
    rightArm: THREE.Group;
    feet: THREE.Group[];
    weapon: THREE.Group;
    shield: THREE.Mesh;
    aim: THREE.Group;
    ring: THREE.Mesh;
    label: THREE.Sprite;
    shadow: THREE.Mesh;
    death: DeathModel;
    leftWeapon?: THREE.Group;
    disguise?: THREE.Group;
    iceBlock?: THREE.Mesh;
    hands?: THREE.Group[];
    limbs?: THREE.Mesh[];
}
export declare function createCharacter(actor: Actor): CharacterView;
export declare function updateCharacter(view: CharacterView, actor: Actor, alpha: number, time: number): void;
