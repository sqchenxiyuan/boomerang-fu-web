import type { Actor } from '../core/types.js';
export declare const MELEE_SETTLE = 0.38;
/** Existing melee-only recovery distinguishes a slash from throw cooldown.
 * No wall clock or renderer history: pause, late attachment and rewind agree. */
export declare function meleeAge(actor: Actor, alpha?: number): number | null;
export declare function sampleMeleePose(age: number, armed: boolean): {
    weight: number;
    angle: number;
    twist: number;
    lean: number;
    height: number;
    stretch: number;
    step: number;
    handX: number;
    handZ: number;
    handY: number;
    trail: number;
};
