import * as THREE from 'three';
/** Two feathered ribbons per actor, in one draw call. Buffers never resize. */
export declare class MeleeTrail {
    readonly mesh: THREE.Mesh<THREE.BufferGeometry, THREE.MeshBasicMaterial>;
    private positions;
    private colors;
    private color;
    private used;
    count: number;
    constructor();
    begin(): void;
    add(x: number, z: number, facing: number, age: number): void;
    end(): void;
    clear(): void;
    dispose(): void;
}
