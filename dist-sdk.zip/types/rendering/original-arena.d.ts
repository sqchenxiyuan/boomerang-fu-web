import type { Arena } from '../core/types.js';
import type { Vec2 } from '../core/math.js';
import type { ArenaView } from './arena-view.js';
export declare function createOriginalArenaView(arena: Arena): ArenaView;
/** Runtime owns all pose/state. No browser clock advances a mechanism here. */
export declare function updateOriginalArena(view: ArenaView, arena: Arena, time: number, alpha?: number): void;
/** Only immutable geometry enters this root. Keep movable/destructible floor and
 * wall nodes reachable; no topology rebuild is needed on navigation revisions. */
export declare function mergeOriginalStatics(view: ArenaView, arena: Arena): number;
export declare function flashOriginalGate(view: ArenaView, point: Vec2, time: number): void;
