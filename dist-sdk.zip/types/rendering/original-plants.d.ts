import * as THREE from 'three';
import type { Arena, EnvironmentMechanism } from '../core/types.js';
/** One opaque batch for all Plant triggers, including plants with no Obstacle. */
export declare class OriginalPlantsView {
    readonly mesh: THREE.InstancedMesh<THREE.BufferGeometry, THREE.MeshStandardMaterial>;
    readonly ids: Map<string, number>;
    private pose;
    private color;
    private green;
    private autumn;
    private burnt;
    private readonly autumnScene;
    constructor(arena: Arena);
    update(mechanisms: Map<string, EnvironmentMechanism>, time: number, alpha: number, elevationDelta: (mechanism: EnvironmentMechanism) => number): void;
}
