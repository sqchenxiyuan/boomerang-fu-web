import * as THREE from 'three';
import type { Vec2 } from '../core/math.js';
/** Keep the core's even-odd fill rule: disjoint islands, holes and islands in
 * holes are all supported. Shape-space Y is negated before the XZ rotation. */
export declare function contourShapes(paths: Vec2[][]): THREE.Shape[];
/** Local (x,y) contours become Three (x,height,z=y), with the bottom at zero. */
export declare function extrudeContours(paths: Vec2[][], height: number): THREE.BufferGeometry;
export declare function rectanglePath(x: number, y: number): Vec2[][];
