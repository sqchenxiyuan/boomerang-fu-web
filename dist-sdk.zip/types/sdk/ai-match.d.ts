import type { GameState, MatchOptions } from '../core/types.js';
import type { Action } from './types.js';
import type { ReplayData } from './recording.js';
export interface AgentObservation {
    protocol: 'boomerang-garden.agent.v1';
    actorId: number;
    tick: number;
    dt: number;
    actionTicks: number;
    state: GameState;
}
/** DOM-free subset implemented by native AbortSignal in Node and browsers. */
export interface AgentSignal {
    readonly aborted: boolean;
    addEventListener(type: 'abort', listener: () => void, options?: {
        once?: boolean;
    }): void;
    removeEventListener(type: 'abort', listener: () => void): void;
}
export type AgentPolicy = (observation: AgentObservation, signal: AgentSignal) => Action | Promise<Action>;
export interface AIMatchOptions {
    match?: Partial<MatchOptions>;
    agents?: Record<number, AgentPolicy>;
    actionTicks?: number;
    timeoutMs?: number;
    maxTicks?: number;
    record?: boolean;
    signal?: AgentSignal;
    onProgress?: (progress: {
        tick: number;
        state: GameState;
    }) => void;
}
export interface AIMatchResult {
    completed: boolean;
    reason: 'match-end' | 'tick-limit' | 'aborted';
    ticks: number;
    simulationSeconds: number;
    wallSeconds: number;
    simulationRate: number;
    state: GameState;
    agentErrors: {
        actorId: number;
        tick: number;
        message: string;
    }[];
    recording: ReplayData | null;
}
/** Run fixed 60 Hz physics as fast as the host permits, yielding between bounded batches.
 * All external agents see the same pre-step state. Network waits do not advance simulation. */
export declare function runAIMatch(options?: AIMatchOptions): Promise<AIMatchResult>;
/** Host-supplied endpoint; secrets belong in the host, never in replay files or observations. */
export declare function createHttpAgent(url: string, headers?: Record<string, string>): AgentPolicy;
