import { GameSession } from './session.js';
import type { GameEvent, GameState, MatchOptions } from '../core/types.js';
import type { SessionSnapshot } from './types.js';
import { AudioEngine } from '../platform/audio.js';
import type { AudioSettings } from '../platform/audio.js';
import { ReplayPlayer } from './recording.js';
import type { ReplayData, RecordingStatus } from './recording.js';
import { FixedLoop } from '../platform/loop.js';
export interface BrowserFrame {
    state: GameState;
    status: SessionSnapshot['status'];
    alpha: number;
    elapsed: number;
    dt: number;
    events: GameEvent[];
    muted: boolean;
    audio: AudioSettings;
    speed: number;
    recording: RecordingStatus | null;
    replay: {
        tick: number;
        durationTicks: number;
        status: ReplayPlayer['status'];
        label: string;
    } | null;
    replayError: string | null;
}
export interface BrowserGameOptions {
    match?: Partial<MatchOptions>;
    autoStart?: boolean;
    keyboard?: boolean;
    inputTarget?: HTMLElement;
    hud?: boolean;
    pauseOnBlur?: boolean;
    onFrame?: (frame: BrowserFrame) => void;
    audio?: Partial<AudioSettings>;
    speed?: number;
}
/** Browser-only adapter. The session owns state; this adapter owns exactly one RAF and input device. */
export declare class BrowserGame {
    private readonly container;
    private readonly options;
    readonly session: GameSession;
    readonly canvas: HTMLCanvasElement;
    private readonly renderer;
    private readonly input;
    private readonly audio;
    private readonly loop;
    private readonly unsubscribe;
    private readonly originalPosition;
    private readonly overlay;
    private readonly wipe;
    private readonly center;
    private readonly score;
    private readonly notice;
    private events;
    private disposed;
    private preview;
    private frames;
    private elapsed;
    private frameErrors;
    private player;
    private replayError;
    onFrame: (frame: BrowserFrame) => void;
    constructor(container: HTMLElement, options?: BrowserGameOptions);
    private assertLive;
    private focus;
    private blur;
    private visibility;
    start(options?: Partial<MatchOptions>): void;
    pause(): void;
    resume(): void;
    /** A paused world rendered as a menu diorama; no hidden match runs in the background. */
    showPreview(options?: Partial<MatchOptions>): void;
    toggleSound(): boolean;
    get playback(): ReplayPlayer | null;
    get speed(): number;
    setSpeed(value: number): void;
    unlockAudio(): void;
    configureAudio(settings: Partial<AudioSettings>): void;
    audioSettings(): AudioSettings;
    loadReplay(data: ReplayData | string): void;
    seekReplay(tick: number): void;
    stats(): {
        frames: number;
        elapsed: number;
        frameErrors: number;
        render: {
            calls: number;
            triangles: number;
            geometries: number;
            textures: number;
        };
        audio: ReturnType<AudioEngine['stats']>;
        clock: ReturnType<FixedLoop['stats']>;
        replayError: string | null;
    };
    destroy(): void;
}
export declare function createBrowserGame(container: HTMLElement, options?: BrowserGameOptions): BrowserGame;
export type { Action, ScriptController, SessionSnapshot, SessionEvent, ControlHandle, ExternalController, } from './types.js';
