import type { Command, GameEvent, GameState } from '../core/types.js';
import { Game } from '../simulation/game.js';
import type { SimulationCheckpoint } from '../simulation/game.js';
export declare const REPLAY_VERSION = 1;
export declare const SIMULATION_VERSION = "0.6.0";
export declare const MAP_DATA_VERSION = "2f74e5c3393ef5555a3f91e461dd581fab65bad2154870d91503698649600e44";
export declare const MAX_REPLAY_TICKS: number;
export declare const MAX_REPLAY_BYTES: number;
export type ReplayOperation = {
    type: 'step';
    count: number;
    commands: [number, Command][];
} | {
    type: 'reset';
    actors: number[];
};
export interface ReplayCheckpoint {
    tick: number;
    operation: number;
    world: SimulationCheckpoint;
    hash: string;
}
export interface ReplayData {
    format: 'boomerang-garden.replay';
    version: number;
    simulationVersion: string;
    mapDataVersion: string;
    tickRate: number;
    createdAt: string;
    durationTicks: number;
    label: string;
    operations: ReplayOperation[];
    checkpoints: ReplayCheckpoint[];
    finalHash: string;
    stopReason: 'manual' | 'match-end' | 'restart' | 'destroy' | 'limit' | 'size-limit';
}
export interface RecordingOptions {
    label?: string;
    checkpointInterval?: number;
    maxTicks?: number;
}
export interface RecordingStatus {
    ticks: number;
    seconds: number;
    checkpoints: number;
    operations: number;
    estimatedBytes: number;
}
/** Drift detection, not authentication. Ignore sub-nanounit floating point differences
 * between JS engine math implementations; RNG and integer identifiers stay exact. */
export declare function checkpointHash(value: SimulationCheckpoint): string;
export declare class MatchRecorder {
    private data;
    private interval;
    readonly maxTicks: number;
    private lastCommands;
    private sealed;
    private bytes;
    get full(): boolean;
    constructor(game: Game, options?: RecordingOptions);
    get status(): RecordingStatus;
    step(commands: ReadonlyMap<number, Command>): void;
    reset(actorId: number): void;
    capture(game: Game): void;
    private checkpoint;
    finish(game: Game, reason: ReplayData['stopReason']): ReplayData;
}
/** Validate data before it reaches physics or Three.js. No recorded JavaScript is executed. */
export declare function parseReplay(input: string | unknown): ReplayData;
/** Action playback is independent of current human, bot, script or remote AI controllers. */
export declare class ReplayPlayer {
    private data;
    private game;
    private operation;
    private repeat;
    private cursor;
    private pending;
    private stopped;
    private paused;
    constructor(input: ReplayData | string);
    get tick(): number;
    get durationTicks(): number;
    get status(): 'playing' | 'paused' | 'ended';
    get label(): string;
    getState(): GameState;
    checkpoint(): SimulationCheckpoint;
    drainEvents(): GameEvent[];
    pause(): void;
    resume(): void;
    private resets;
    private advance;
    step(ticks?: number): void;
    seek(tick: number): void;
}
