import type { DeathCause, MapId, PowerupKind } from '../core/types.js';
import type { ReplayData } from './recording.js';
export type ReplayMarkerKind = 'round' | 'death' | 'pickup' | 'deflect' | 'win';
export interface ReplayMarker {
    id: string;
    tick: number;
    kind: ReplayMarkerKind;
    round: number;
    mapId: MapId;
    actorId: number;
    sourceId?: number;
    cause?: DeathCause;
    power?: PowerupKind;
}
export interface ReplayTimelineSnapshot {
    status: 'indexing' | 'ready' | 'error';
    progress: number;
    markers: readonly Readonly<ReplayMarker>[];
    error: string | null;
    omitted: number;
}
/** Incremental deterministic event index for existing replay files, including version 1.
 * Hosts choose the work budget and can cancel simply by dropping the instance. */
export declare class ReplayTimeline {
    private player;
    private markers;
    private round;
    private mapId;
    private error;
    private omitted;
    private cache;
    constructor(data: ReplayData | string);
    private add;
    advance(ticks?: number): void;
    snapshot(): ReplayTimelineSnapshot;
}
