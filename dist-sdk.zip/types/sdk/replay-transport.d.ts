import { ReplayPlayer } from './recording.js';
import type { ReplayData } from './recording.js';
export interface ReplayLoop {
    start: number;
    end: number;
}
export interface ReplayTransportSnapshot {
    /** Process-local player identity, independent of the persisted recording identity. */
    id: number;
    tick: number;
    durationTicks: number;
    status: ReplayPlayer['status'];
    label: string;
    loop: ReplayLoop | null;
    scrubbing: boolean;
    /** Changes on discontinuities, so a host can invalidate visual/audio effects. */
    revision: number;
}
export declare class ReplayTransport {
    private readonly id;
    readonly player: ReplayPlayer;
    private range;
    private scrub;
    private revision;
    constructor(data: ReplayData | string);
    snapshot(): ReplayTransportSnapshot;
    pause(): void;
    resume(): void;
    toggle(): void;
    seek(tick: number): void;
    /** Signed tick movement always leaves playback paused, including at either boundary. */
    stepFrames(delta: number): void;
    setLoop(range: ReplayLoop | null): void;
    beginScrub(): void;
    endScrub(cancel?: boolean): void;
    /** Consume host-supplied simulation ticks, wrapping an A–B loop without changing physics dt. */
    advance(ticks?: number): void;
}
