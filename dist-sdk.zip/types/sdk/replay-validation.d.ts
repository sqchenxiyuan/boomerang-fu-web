export declare function validateReplayState(value: unknown): void;
