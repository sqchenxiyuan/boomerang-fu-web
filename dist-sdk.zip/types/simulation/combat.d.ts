import type { Vec2 } from '../core/math.js';
import type { Actor, DeathCause, GameState, Obstacle, PowerupKind } from '../core/types.js';
export declare function breakCrate(state: GameState, obstacle: Obstacle, actorId: number, hitSerial?: number): void;
export declare function damageActor(state: GameState, actor: Actor, sourceId: number, direction: Vec2, cause?: DeathCause): 'ignored' | 'shield' | 'killed';
export declare function facingTarget(actor: Actor, position: Vec2, threshold?: number): boolean;
export declare function resolveMelee(state: GameState): void;
export declare function explode(state: GameState, position: Vec2, sourceId: number, powers?: readonly PowerupKind[], scale?: number): void;
export declare function separateActors(state: GameState): void;
