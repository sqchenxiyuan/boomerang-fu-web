import type { Random } from '../core/math.js';
import type { EnvironmentStrike } from '../core/environment-types.js';
import type { GameState, Obstacle } from '../core/types.js';
/** Public for deterministic SDK/debug controls; switches call this same state machine. */
export declare function activateEnvironment(state: GameState, id: string, actorId?: number): boolean;
/** Advance before player movement. Moving bodies and floor support are authoritative. */
export declare function tickEnvironment(state: GameState, random: Random, dt: number): void;
/** Original trigger overlap plus nine-point ordinary-ground support test. */
export declare function tickEnvironmentContacts(state: GameState, dt: number): void;
export declare function damageEnvironmentObstacle(state: GameState, obstacle: Obstacle, actorId: number, serial?: number): boolean;
export declare function strikeEnvironment(state: GameState, strike: EnvironmentStrike): void;
