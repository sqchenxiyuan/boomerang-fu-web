import type { Command, GameEvent, GameState, MatchOptions } from '../core/types.js';
export interface SimulationCheckpoint {
    state: GameState;
    randomSeed: number;
}
/** Sole authoritative owner of gameplay state. No rendering or DOM dependencies. */
export declare class Game {
    state: GameState;
    private random;
    constructor(options?: MatchOptions);
    start(options: MatchOptions): void;
    checkpoint(): SimulationCheckpoint;
    /** Restore into fresh object identities so geometry/navigation caches cannot survive a seek. */
    restore(checkpoint: SimulationCheckpoint): void;
    step(commands?: ReadonlyMap<number, Command>): void;
    drainEvents(): GameEvent[];
}
