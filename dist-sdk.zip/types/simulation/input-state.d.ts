import type { Actor } from '../core/types.js';
/** Control changes and pause cancel held actions without generating release edges.
 * Replays record this mutation as well as the commands consumed by physics. */
export declare function clearActorInput(actor: Actor): boolean;
