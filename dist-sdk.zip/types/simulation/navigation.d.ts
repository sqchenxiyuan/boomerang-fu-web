import type { Vec2 } from '../core/math.js';
import type { Arena } from '../core/types.js';
export interface NavigationWaypoint extends Vec2 {
    /** This edge must be traversed by entering a portal, never by walking across the map. */
    portalId?: string;
    viaPortal?: string;
}
export declare const threatenedFloor: (arena: Arena, point: Vec2) => boolean;
export declare function clearPathSegment(arena: Arena, a: Vec2, b: Vec2, clearance?: number, allowWarnings?: boolean): boolean;
/** Leave a collapsing tile before resuming combat; only choose a supported route. */
export declare function findFloorEscape(arena: Arena, start: Vec2, heading?: Vec2): Vec2 | null;
/** A* without portals, Dijkstra with shortcuts; Euclidean heuristics overestimate portal routes. */
export declare function findPath(arena: Arena, start: Vec2, goal: Vec2): NavigationWaypoint[];
/** Advance after an actual teleport as well as normal walking. A portal cannot be skipped early. */
export declare function advancePath(path: NavigationWaypoint[], position: Vec2): void;
